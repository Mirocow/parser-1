<?php
namespace pistol88\shop\events;

use yii\base\Event;

class ProductEvent extends Event
{
    public $model;
}